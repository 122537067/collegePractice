package com.sms.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sms.iservice.IUserInfoService;
import com.sms.model.UserInfo;

@Controller
@RequestMapping("/user")
public class UserInfoController extends BaseController {
	
	@Autowired
	private IUserInfoService userService;
	
	@RequestMapping("/all")
	@ResponseBody
	public List<UserInfo> all() {

		try {
			
			List<UserInfo> users = this.userService.getAllUsers();
			return users;
			
		} catch (Exception ex) {
			logger.error("获取学员信息错误："+ex.getMessage(),ex);
			return null;
		}

	}

}
