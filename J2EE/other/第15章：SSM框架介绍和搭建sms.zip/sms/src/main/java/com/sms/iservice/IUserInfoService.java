package com.sms.iservice;

import java.util.List;

import com.sms.model.UserInfo;

public interface IUserInfoService {
	
	/**
	 * 获取所有用户信息
	 * @return
	 * @throws Exception 
	 */
	public List<UserInfo> getAllUsers() throws Exception;
}
