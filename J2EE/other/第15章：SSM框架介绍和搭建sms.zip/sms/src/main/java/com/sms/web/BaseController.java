package com.sms.web;

import org.apache.log4j.Logger;

/**
 * 控制器的基类，封装一些通用操作
 * @author hp
 *
 */
public class BaseController {
	
	/**
	 * 使用Log4j日志
	 */
	protected Logger logger = Logger.getLogger(this.getClass());

}
