package com.sms.web;


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.sms.model.ReturnData;
import com.sms.model.UserInfo;
import com.sms.service.UserInfoService;

/**
 * 修改用户信息
 * @author hp
 *
 */
@WebServlet("/userinfo/edituser.do")
public class EditUserServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		long Id = Long.parseLong(request.getParameter("Id"));
		String Username = request.getParameter("Username");
		String Password = request.getParameter("Password");
		
		ReturnData rd = new ReturnData();

		try{
			UserInfo user =  new UserInfo();
			
			user.setId(Id);
			user.setUsername(Username);
			user.setPassword(Password);
			
			new UserInfoService().updateUserInfo(user);
		
			rd.setSuccess(true);
			rd.setMessage("修改用户成功");
		}
		catch(Exception ex){
			ex.printStackTrace();
			rd.setSuccess(false);
			rd.setMessage(ex.getMessage());
		}
		
		JSONObject json = new JSONObject(rd);

		response.getWriter().print(json);
	}


}
