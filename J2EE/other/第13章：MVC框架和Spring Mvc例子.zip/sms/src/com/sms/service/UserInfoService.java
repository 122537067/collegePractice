package com.sms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sms.dao.UserInfoDao;
import com.sms.model.UserInfo;

@Service
public class UserInfoService {
	
	@Autowired
	private UserInfoDao dao;
	
	
	/**
	 * 处理用户登录的逻辑，成功登录返回用户信息，否则返回null
	 * @param username
	 * @param pwd
	 * @return
	 */
	public UserInfo login(String username,String pwd){
		UserInfo user = this.dao.getUserInfoByName(username);
		if(user==null) return null;
		
		if(user.getPassword().equals(pwd)) return user;
		
		return null;
		
	}
	
	public UserInfo getUserInfoByID(long id){
		return this.dao.getUserInfoByID(id);
	}
	
	public void updatePwd(UserInfo user) throws Exception{
		this.dao.updatePwd(user.getId(), user.getPassword());
	}
	
	public String getUserInfoJsonData() throws Exception{
		List<UserInfo> users = this.dao.getUserInfos();
		String jsonData =null;// JSONObject.valueToString(users);
		return jsonData;
	}
	
	public void addUserInfo(UserInfo user) throws Exception{
		this.dao.add(user);
	}
	
	public void updateUserInfo(UserInfo user) throws Exception{
		this.dao.update(user);
	}
	
	public void deleteUserInfo(long id) throws Exception{
		this.dao.delete(id);
	}

}
