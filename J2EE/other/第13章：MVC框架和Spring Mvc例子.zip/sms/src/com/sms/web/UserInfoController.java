package com.sms.web;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sms.model.UserInfo;
import com.sms.service.UserInfoService;

@Controller
public class UserInfoController {
	
	@Autowired
	private UserInfoService service;
	
	@RequestMapping(value="/login",method=RequestMethod.GET)
	public String login(){
		return "login";
	}
	
	// @RequestMapping(value="/login",method=RequestMethod.POST,produces="text/html;charset=UTF-8") // 统一配置后，不需要单独编码
	@RequestMapping(value="/login",method=RequestMethod.POST)
	@ResponseBody
	public String login(HttpServletRequest request,HttpServletResponse response,@RequestParam String username,@RequestParam String pwd ) throws UnsupportedEncodingException{

		UserInfo user = this.service.login(username, pwd);
		
		if(user==null) {
			return "用户名或者密码错误";
		}
		
		request.getSession().setAttribute("user", user);
		
		return "success";
	}

}
