package com.sms.model;

/**
 * 班级信息实体对象
 * @author hp
 *
 */
public class ClassInfo {
	
	private long id;
	
	private String name;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
}
