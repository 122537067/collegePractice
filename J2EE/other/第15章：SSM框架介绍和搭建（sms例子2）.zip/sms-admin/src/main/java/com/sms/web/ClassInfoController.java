package com.sms.web;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sms.iservice.IClassInfoService;
import com.sms.model.ClassInfo;

@Controller
@RequestMapping("/classinfo")
public class ClassInfoController extends BaseController {
	
	@Autowired
	private IClassInfoService service;
	
	@RequestMapping(value="/list",method=RequestMethod.GET)
	public String list(HttpServletRequest request){
		return "classinfo/list";
	}
	
	@RequestMapping(value="/list",method=RequestMethod.POST)
	@ResponseBody
	public List<ClassInfo> list() throws Exception{
		List<ClassInfo> data = this.service.getAllClassInfos();
		return data;
	}

}
