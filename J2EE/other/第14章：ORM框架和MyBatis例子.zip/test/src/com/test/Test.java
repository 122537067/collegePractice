package com.test;

import java.io.IOException;
import java.io.Reader;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.sms.dao.IUserInfoDao;
import com.sms.model.UserInfo;
import com.sms.service.UserInfoService;

public class Test {
	
	public static void main(String[] args) throws Exception{

		
		List<UserInfo> users = new UserInfoService().getAllUsers();
		
		for(UserInfo user:users){
			System.out.println(user.toString());
		}
		
		System.out.println("ok");
	}

}
