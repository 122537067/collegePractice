package com.sms.test;

import java.util.List;

import com.sms.model.UserInfo;
import com.sms.service.UserInfoService;

public class Test3 {
	
	public static void main(String[] args) throws Exception {
		
		UserInfoService service = new UserInfoService();
		
		UserInfo user = new UserInfo();
		user.setUsername("testuser123");
		user.setPassword("pwd123");
		
		service.addUser(user);
		
		List<UserInfo> users = service.getAllUsers();
		
		for(UserInfo u:users){
			System.out.println(u.toString());
		}
	}

}
