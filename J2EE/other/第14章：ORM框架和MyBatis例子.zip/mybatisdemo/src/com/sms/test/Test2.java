package com.sms.test;

import java.io.Reader;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.sms.dao.IUserInfoDao;
import com.sms.model.UserInfo;

public class Test2 {
	
	public static void main(String[] args) throws Exception {

		Reader reader = Resources.getResourceAsReader("mybatis.cfg.xml");
		SqlSessionFactory sessionFactory = new SqlSessionFactoryBuilder().build(reader);
		
		// 自动提交事务
		SqlSession session = sessionFactory.openSession(true);
		IUserInfoDao dao = session.getMapper(IUserInfoDao.class);
		
		UserInfo user = new UserInfo();
		user.setUsername("newUser");
		user.setPassword("123456");
		
		dao.insertUser(user);
		
		List<UserInfo> users = dao.selectAllUser();
		for(UserInfo u:users){
			System.out.println(u);
		}
		
		
	}

}
