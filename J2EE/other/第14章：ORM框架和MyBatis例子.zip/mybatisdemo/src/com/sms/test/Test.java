package com.sms.test;

import java.io.Reader;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class Test {
	
	public static void main(String[] args) throws Exception {
		
		//使用MyBatis提供的Resources类加载mybatis的配置文件
		Reader reader = Resources.getResourceAsReader("mybatis.cfg.xml");
		
		//构建sqlSession的工厂
		SqlSessionFactory sessionFactory = new SqlSessionFactoryBuilder().build(reader);
		
		SqlSession session = sessionFactory.openSession();
		PreparedStatement ps  = session.getConnection().prepareStatement("select * from UserInfo");
		
		ResultSet rs = ps.executeQuery();
		
		while(rs.next()){
			System.out.println("username:"+rs.getString("Username")+",password:"+rs.getString("Password"));
		}
		
		ps.close();
	}

}
