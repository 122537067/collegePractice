package com.sms.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.sms.dao.DbHelper;
import com.sms.dao.IUserInfoDao;
import com.sms.model.UserInfo;

public class UserInfoService {
	
	private IUserInfoDao userDao;
	
	public UserInfoService(){
		SqlSession session = DbHelper.getSession();
		this.userDao = session.getMapper(IUserInfoDao.class);
	}
	
	public void addUser(UserInfo user) throws Exception{
		this.userDao.insertUser(user);
	}
	
	public List<UserInfo> getAllUsers() throws Exception{
		return this.userDao.selectAllUser();
	}

}
