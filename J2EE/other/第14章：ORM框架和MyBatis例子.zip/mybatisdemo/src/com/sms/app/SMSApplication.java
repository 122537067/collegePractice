package com.sms.app;

public class SMSApplication {
	
	public static void main(String[] args) throws Exception {
		
	}

}
