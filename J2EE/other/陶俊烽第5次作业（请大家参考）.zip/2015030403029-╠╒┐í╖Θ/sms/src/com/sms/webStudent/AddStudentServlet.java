package com.SMS3.webStudent;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.SMS3.dao.StudentInfoDao;
import com.SMS3.model.StudentInfo;
import com.SMS3.web.PermissionHelper;

@WebServlet("/AddStudent.web")
public class AddStudentServlet  extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		if(!(PermissionHelper.validPermission(req, resp,"StudentAdd")))//如果验证不通过，则不继续执行
			return;
		
		try {
			addFromDataBase(req, resp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void addFromDataBase(HttpServletRequest request,
			HttpServletResponse response) throws Exception, ServletException {
		// 以下是处理出现乱码的过滤器
		request.setCharacterEncoding("utf-8");
//		response.setCharacterEncoding("utf-8");

		String submit = request.getParameter("submit");
		String classname=request.getParameter("classname");
		String name = request.getParameter("name");
		String age=request.getParameter("age");
		
		if (submit == null) {
			return;
		}
		if (name !=null &&classname!=null &&age!=null ) {
			try {	
				StudentInfoDao dao = new StudentInfoDao(request);
				StudentInfo t = new StudentInfo();
				t.setClassname(classname);
				t.setName(name);
				t.setAge(Integer.parseInt(age));
				dao.add(t);
				response.sendRedirect("/studentinfo/listStudent.jsp");
			} catch (Exception exception) {
				throw new ServletException(exception);
			}	
		}	
	}
	
}
