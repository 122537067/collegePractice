package com.SMS3.dao;

import javax.servlet.http.HttpServletRequest;

//基于DbHelper实现数据库连接的类
public class BaseDao {
	
	private String driver = null;//连接数据库服务器驱动
	private String url = null;//数据库名称
	private String user = null;//数据库用户名
	private String pwd = null;//数据库密码
	
	public BaseDao(String driver,String url,String user,String pwd){
		this.driver = driver;
		this.url = url;
		this.user = user;
		this.pwd = pwd;
	}
	
	public String getDriver() {
		return driver;
	}
	public void setDriver(String driver) {
		this.driver = driver;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	//以下通过配置文件封装连接数据库的参数
	public BaseDao(HttpServletRequest request){
		this.driver = request.getServletContext().getInitParameter("database_driver");
		this.url = request.getServletContext().getInitParameter("database_url");
		this.user = request.getServletContext().getInitParameter("database_user");
		this.pwd = request.getServletContext().getInitParameter("database_pwd");
	}
	
	//基于DbHelper这个类实现数据库具体的连接
	public DbHelper createDbHelper(){
		return new DbHelper(driver,url,user,pwd);
	}
}
