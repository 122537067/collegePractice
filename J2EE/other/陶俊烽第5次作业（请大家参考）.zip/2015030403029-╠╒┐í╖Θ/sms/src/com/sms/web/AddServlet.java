package com.SMS3.web;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.SMS3.dao.ClassInfoDao;
import com.SMS3.model.ClassInfo;

@WebServlet("/Add.web")
public class AddServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		if (!(PermissionHelper.validPermission(request, response,"ClassAdd"))) {//对添加班级这个功能页面设置权限，如果验证不通过，则返回
			return;
		}
		
			try {
				addFromDataBase(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	private void addFromDataBase(HttpServletRequest request,
			HttpServletResponse response) throws Exception, ServletException {
		// 以下是处理出现乱码的过滤器
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");

		String submit = request.getParameter("submit");
		String name = request.getParameter("name");
		if (submit == null) {
			return;
		}
		if (name ==null ) {
			return;
		}
		try {	
			ClassInfoDao dao = new ClassInfoDao(request);
			ClassInfo c = new ClassInfo();
			c.setName(name);
			dao.add(c);
			response.sendRedirect("/classinfo/list.jsp");
		} catch (Exception exception) {
			throw new ServletException(exception);
		}	
	}

}
