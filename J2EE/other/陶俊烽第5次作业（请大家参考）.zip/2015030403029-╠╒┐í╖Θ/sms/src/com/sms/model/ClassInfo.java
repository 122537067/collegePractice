package com.SMS3.model;

//班级实体类
public class ClassInfo {
	private long id;//班级编号
	
	private String name;//班级名称

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
