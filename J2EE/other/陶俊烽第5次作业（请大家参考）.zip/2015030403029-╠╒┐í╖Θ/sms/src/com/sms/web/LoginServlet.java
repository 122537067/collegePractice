package com.SMS3.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.SMS3.dao.UserInfoDao;
import com.SMS3.model.UserInfo;

//servlet类loginServlet继承基类HttpServlet，用来处理用户登录事件

@WebServlet("/Login.web")//使用命令声明该servlet类，从而与login.jsp实现映射
public class LoginServlet  extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	//重写HttpServlet这个类的方法doPost,用来传递、保存数据
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		loginFromDataBase(req, resp);//通过调用改封装方法实现表单数据的提交和保存
	}
	

	//定义一个处理用户登录业余逻辑的函数，封装该函数
	private void loginFromDataBase(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		//以下是处理出现乱码的过滤器
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		String username=request.getParameter("username");//通过request方法获取用户名参数内容
		String pwd=request.getParameter("pwd");//通过request方法获取密码参数内容
		
		//以下是连接数据库判断用户是否存在并返回结果到login中form属性action
		try {
			//创建一个用户实体对象并获取用户名
			UserInfoDao userDao = new UserInfoDao(request);
			UserInfo userInfo = userDao.getUserByName(username);
//			UserInfo userInfo=new UserInfoDao(request).getUserByName(username);
			
			
			if (userInfo==null) {//提示用户用户不存在，返回登录界面
				response.sendRedirect("/login.jsp?errString=1");
				return;
			}
			if (!(userInfo.getPassword().equals(pwd))) {//提示用户密码错误，返回登录界面
				response.sendRedirect("/login.jsp?errString=2");
				return;
			}
			
			userInfo.setRoles(userDao.loadPermissions(userInfo.getId()));	//对有系统权限的用户加载功能权限
			request.getSession().setAttribute(PermissionHelper.user_session_key, userInfo);
			
			
			//以上情况都不是，则登录成功，跳转到主页
			response.sendRedirect("/index.jsp");
					
		} catch (Exception e) {
			// TODO: handle exception
			throw new ServletException(e);
		}
	}
}
