package com.SMS3.webStudent;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.SMS3.dao.StudentInfoDao;
import com.SMS3.web.PermissionHelper;

@WebServlet("/DeleteStudent.web")
public class DeleteStudentServlet  extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		if(!(PermissionHelper.validPermission(req, resp,"StudentDelete")))//如果验证不通过，则不继续执行
			return;
		
		try {
			deleteFromDataBase(req, resp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	private void  deleteFromDataBase(HttpServletRequest request,HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		String id = request.getParameter("id");

		try {
			StudentInfoDao dao = new StudentInfoDao(request);
			dao.delete(Long.parseLong(id));response.sendRedirect("/studentinfo/listStudent.jsp");
		} catch (Exception exception) {
			throw exception;
		}
		
	}

}
