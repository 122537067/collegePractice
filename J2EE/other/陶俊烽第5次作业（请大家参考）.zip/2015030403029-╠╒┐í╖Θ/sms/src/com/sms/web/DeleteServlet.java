package com.SMS3.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.SMS3.dao.ClassInfoDao;

@WebServlet("/Delete.web")
public class DeleteServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		//对删除班级这个功能页面设置权限,如果验证不通过，则不继续执行
		if (!(PermissionHelper.validPermission(req, resp,"ClassDelete"))) {
			return;
		}
		try {
			
			deleteFromDataBase(req, resp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	private void  deleteFromDataBase(HttpServletRequest request,HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		String id = request.getParameter("id");

		try {
			ClassInfoDao dao = new ClassInfoDao(request);
			dao.delete(Long.parseLong(id));
			response.sendRedirect("/classinfo/list.jsp");
		} catch (Exception exception) {
			throw exception;
		}
		
	}
	
}
