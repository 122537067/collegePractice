package com.SMS3.model;

/*
 学生实体类
 * */
public class StudentInfo {
	private long id;// 学生编号
	private String classname;// 班级名称
	private String name;// 学生姓名
	private int	 age;//学生年龄
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getClassname() {
		return classname;
	}

	public void setClassname(String classname) {
		this.classname = classname;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	
	
}
