package com.SMS3.webStudent;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.SMS3.dao.StudentInfoDao;
import com.SMS3.model.StudentInfo;
import com.SMS3.web.PermissionHelper;

@WebServlet("/ModifyStudent.web")
public class ModifyStudentServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		if(!(PermissionHelper.validPermission(req, resp,"StudentModify")))//如果验证不通过，则不继续执行
			return;
		
		try {
			modifyFromDataBase(req, resp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void  modifyFromDataBase(HttpServletRequest request,HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
//		response.setCharacterEncoding("uft-8");
		
		String id = request.getParameter("id");
		String classname=request.getParameter("classname");
		String name = request.getParameter("name");
		String age=request.getParameter("age");
		try{
			StudentInfoDao dao = new StudentInfoDao(request);
			StudentInfo t = new StudentInfo();
			t.setId(Long.parseLong(id));
			t.setClassname(classname);
			t.setName(name);
			t.setAge(Integer.parseInt(age));
			dao.update(t);
			response.sendRedirect("/studentInfo/listStudent.jsp");
		}catch(Exception exception){
			throw exception;
		}
		
	}

}
