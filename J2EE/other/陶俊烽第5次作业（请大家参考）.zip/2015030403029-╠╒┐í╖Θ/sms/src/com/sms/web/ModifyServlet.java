package com.SMS3.web;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.SMS3.dao.ClassInfoDao;
import com.SMS3.model.ClassInfo;


@WebServlet("/Modify.web")
public class ModifyServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		//通过PermissionHelper方法对修改班级页面添加权限 ,如果验证不通过，则不继续执行
		if (!(PermissionHelper.validPermission(req, resp, "ClassModif"))) {
			return;
		}
		
		try {
			modifyFromDataBase(req, resp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void  modifyFromDataBase(HttpServletRequest request,HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
//		response.setCharacterEncoding("uft-8");
		
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		try{
			ClassInfoDao dao = new ClassInfoDao(request);
			ClassInfo c = new ClassInfo();
			c.setId(Long.parseLong(id));
			c.setName(name);
			dao.update(c);
			response.sendRedirect("/classinfo/list.jsp");
		}catch(Exception exception){
			throw exception;
		}	
	}
}
