package com.SMS3.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import com.SMS3.model.StudentInfo;

public class StudentInfoDao extends BaseDao {

	//构造函数，通过关键字super调用BaseDao的方法连接数据库
	public StudentInfoDao(HttpServletRequest request) {
		super(request);
	}

	//添加学生信息
	public void add(StudentInfo model) throws Exception{
		DbHelper db = this.createDbHelper();//创建连接对象

		//创建一个哈希对象，用来存储学生所在班级、姓名、年龄
		Map<String,Object> param = new LinkedHashMap<String,Object>();
		param.put("ClassName",model.getClassname());
		param.put("Name",model.getName() );
		param.put("Age", model.getAge());
		
		db.createConnection();//连接数据库
		
		db.execute("insert into StudentInfo(ClassName,Name,Age) values(?,?,?)", param);//执行添加班级的操作
		
		db.closeConnection();//关闭数据库
	}
	
	//更新班级信息
	public void update(StudentInfo model) throws Exception{
		DbHelper db = this.createDbHelper();
		
		Map<String,Object> param = new LinkedHashMap<String,Object>();	
		param.put("Age", model.getAge());
		param.put("Name",model.getName());
		param.put("ClassName",model.getClassname());
		param.put("Id",model.getId());
		
		db.createConnection();
		
		db.execute("update StudentInfo set Age=? ,Name=? ,ClassName=? where Id=?" , param);
		
		db.closeConnection();
	}
	
	//查询学生信息
	public StudentInfo get(long id) throws Exception{
		DbHelper db = this.createDbHelper();
		
		Map<String,Object> param = new LinkedHashMap<String,Object>();
		param.put("Id",id);
		
		db.createConnection();
		
		//创建一个结果集对象，用来存储查询数据库表后的结果，一般对应一个表
		ResultSet rs = db.query("select * from StudentInfo where Id=?", param);
		
		StudentInfo model = null;//创建一个空的实体学生对象
		
		//next()方法的返回值是一个boolean型的值，该值若为true, 说明结果集中存在记录
		if(rs.next()){//结果集对象不空
			//以下将结果集对象中的数据传给实体类对象model，对应学生编号，学生名称
			model = new StudentInfo();
			model.setId(rs.getLong(1));
			model.setClassname(rs.getString(2));
			model.setName(rs.getString(3));
			model.setAge(rs.getInt(4));
		}
		
		db.closeConnection();
		
		return model;
	}
	
	//删除学生信息
	public void delete(long id) throws Exception{
		String sql = "delete from StudentInfo where Id=?";
		Map<String,Object> param = new LinkedHashMap<String,Object>();
		param.put("Id",id);
		
		DbHelper db = this.createDbHelper();
		db.createConnection();
		db.execute(sql, param);
		db.closeConnection();
	}
	
	
	//实现模糊查询
	public List<StudentInfo> query(String name) throws Exception{
		String sql = "select * from StudentInfo";
		
		if(name!=null && name.length()>0){
			sql += " where Name like '%"+name+"%'";
		}
		
		DbHelper db = this.createDbHelper();
		
		db.createConnection();
		
		ResultSet rs = db.query(sql, null);
		
		List<StudentInfo> list = new ArrayList<StudentInfo>();

		while(rs.next()){
			StudentInfo model = new StudentInfo();
			model.setId(rs.getLong(1));
			model.setClassname(rs.getString(2));
			model.setName(rs.getString(3));
			model.setAge(rs.getInt(4));

			list.add(model);
		}
		
		db.closeConnection();
		
		return list;
	}
}
