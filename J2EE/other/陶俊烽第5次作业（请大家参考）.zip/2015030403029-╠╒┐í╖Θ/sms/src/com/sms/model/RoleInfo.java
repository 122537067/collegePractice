package com.SMS3.model;

import java.util.List;

//该实体类是记录角色的相关信息，
public class RoleInfo {
	
	private long id;//角色编号
	private String code;//角色编码，即字典
	private String name;//角色名
	private List<FunctionInfo> functions;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public List<FunctionInfo> getFunctions() {
		return functions;
	}
	public void setFunctions(List<FunctionInfo> functions) {
		this.functions = functions;
	}
	
}

