package com.SMS3.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.SMS3.model.ClassInfo;

//继承BaseDao实现数据库连接、修改数据
public class ClassInfoDao extends BaseDao {

	//构造函数，通过关键字super调用BaseDao的方法连接数据库
	public ClassInfoDao(HttpServletRequest request) {
		super(request);
	}

	//添加班级信息
	public void add(ClassInfo model) throws Exception{
		DbHelper db = this.createDbHelper();//创建连接对象

		//创建一个哈希对象，用来存储班级名称
		Map<String,Object> param = new LinkedHashMap<String,Object>();
		param.put("Name",model.getName());
		
		db.createConnection();//连接数据库
		
		db.execute("insert into ClassInfo(Name) values(?)", param);//执行添加班级的操作
		
		db.closeConnection();//关闭数据库
	}
	
	//更新班级信息
	public void update(ClassInfo model) throws Exception{
		DbHelper db = this.createDbHelper();
		
		Map<String,Object> param = new LinkedHashMap<String,Object>();
		param.put("Name",model.getName());
		param.put("Id",model.getId());
		
		db.createConnection();
		
		db.execute("update ClassInfo set Name=? where Id=?", param);
		
		db.closeConnection();
	}
	
	//查询班级信息
	public ClassInfo get(long id) throws Exception{
		DbHelper db = this.createDbHelper();
		
		Map<String,Object> param = new LinkedHashMap<String,Object>();
		param.put("Id",id);
		
		db.createConnection();
		
		//创建一个结果集对象，用来存储查询数据库表后的结果，一般对应一个表
		ResultSet rs = db.query("select * from ClassInfo where Id=?", param);
		
		ClassInfo model = null;//创建一个空的实体班级对象
		
		//next()方法的返回值是一个boolean型的值，该值若为true, 说明结果集中存在记录
		if(rs.next()){//结果集对象不空
			//以下将结果集对象中的数据传给实体类对象model，对应班级编号，班级名称
			model = new ClassInfo();
			model.setId(rs.getLong(1));
			model.setName(rs.getString(2));
		}
		
		db.closeConnection();
		
		return model;
	}
	
	//删除班级信息
	public void delete(long id) throws Exception{
		String sql = "delete from ClassInfo where Id=?";
		Map<String,Object> param = new LinkedHashMap<String,Object>();
		param.put("Id",id);
		
		DbHelper db = this.createDbHelper();
		db.createConnection();
		db.execute(sql, param);
		db.closeConnection();
	}
	
	
	//实现模糊查询
	public List<ClassInfo> query(String name) throws Exception{
		String sql = "select * from ClassInfo";
		
		if(name!=null && name.length()>0){
			sql += " where Name like '%"+name+"%'";
		}
		
		DbHelper db = this.createDbHelper();
		
		db.createConnection();
		
		ResultSet rs = db.query(sql, null);
		
		List<ClassInfo> list = new ArrayList<ClassInfo>();

		while(rs.next()){
			ClassInfo model = new ClassInfo();
			model.setId(rs.getLong(1));
			model.setName(rs.getString(2));

			list.add(model);
		}
		
		db.closeConnection();
		
		return list;
	}

}
