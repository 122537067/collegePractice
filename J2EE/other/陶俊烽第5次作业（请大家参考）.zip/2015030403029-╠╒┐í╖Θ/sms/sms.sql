/*
Navicat MySQL Data Transfer

Source Server         : zeng
Source Server Version : 50715
Source Host           : localhost:3306
Source Database       : sms

Target Server Type    : MYSQL
Target Server Version : 50715
File Encoding         : 65001

Date: 2018-04-03 23:18:39
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `classinfo`
-- ----------------------------
DROP TABLE IF EXISTS `classinfo`;
CREATE TABLE `classinfo` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of classinfo
-- ----------------------------
INSERT INTO `classinfo` VALUES ('1', '7771班');
INSERT INTO `classinfo` VALUES ('6', '修改了');
INSERT INTO `classinfo` VALUES ('13', 'aa');
INSERT INTO `classinfo` VALUES ('15', 'bb');

-- ----------------------------
-- Table structure for `courseinfor`
-- ----------------------------
DROP TABLE IF EXISTS `courseinfor`;
CREATE TABLE `courseinfor` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `No` varchar(18) COLLATE utf8_unicode_ci NOT NULL,
  `Name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of courseinfor
-- ----------------------------
INSERT INTO `courseinfor` VALUES ('1', 'A100', 'Java');
INSERT INTO `courseinfor` VALUES ('2', 'A101', 'C++');

-- ----------------------------
-- Table structure for `functioninfo`
-- ----------------------------
DROP TABLE IF EXISTS `functioninfo`;
CREATE TABLE `functioninfo` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Code` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of functioninfo
-- ----------------------------
INSERT INTO `functioninfo` VALUES ('1', 'ClassList', '班级列表');
INSERT INTO `functioninfo` VALUES ('2', 'ClassAdd', '添加班级');
INSERT INTO `functioninfo` VALUES ('3', 'ClassModif', '修改班级');
INSERT INTO `functioninfo` VALUES ('4', 'ClassDelete', '删除班级');
INSERT INTO `functioninfo` VALUES ('5', 'index', '主页');
INSERT INTO `functioninfo` VALUES ('6', 'StudentAdd', '添加学生');
INSERT INTO `functioninfo` VALUES ('7', 'StudentList', '学生列表');
INSERT INTO `functioninfo` VALUES ('8', 'StudentModify', '修改学生');
INSERT INTO `functioninfo` VALUES ('9', 'StudentDelete', '删除学生');

-- ----------------------------
-- Table structure for `rolefunctionpermission`
-- ----------------------------
DROP TABLE IF EXISTS `rolefunctionpermission`;
CREATE TABLE `rolefunctionpermission` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `RoleInfoId` bigint(20) NOT NULL,
  `FunctionInfoId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of rolefunctionpermission
-- ----------------------------
INSERT INTO `rolefunctionpermission` VALUES ('1', '1', '1');
INSERT INTO `rolefunctionpermission` VALUES ('2', '1', '2');
INSERT INTO `rolefunctionpermission` VALUES ('3', '1', '3');
INSERT INTO `rolefunctionpermission` VALUES ('4', '1', '4');
INSERT INTO `rolefunctionpermission` VALUES ('5', '1', '5');
INSERT INTO `rolefunctionpermission` VALUES ('6', '3', '1');
INSERT INTO `rolefunctionpermission` VALUES ('7', '3', '5');
INSERT INTO `rolefunctionpermission` VALUES ('8', '3', '6');
INSERT INTO `rolefunctionpermission` VALUES ('9', '3', '7');
INSERT INTO `rolefunctionpermission` VALUES ('10', '3', '8');
INSERT INTO `rolefunctionpermission` VALUES ('11', '3', '9');

-- ----------------------------
-- Table structure for `roleinfo`
-- ----------------------------
DROP TABLE IF EXISTS `roleinfo`;
CREATE TABLE `roleinfo` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Code` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of roleinfo
-- ----------------------------
INSERT INTO `roleinfo` VALUES ('1', 'admin', '管理员');
INSERT INTO `roleinfo` VALUES ('2', 'manager', '经理');
INSERT INTO `roleinfo` VALUES ('3', 'teacher', '老师');

-- ----------------------------
-- Table structure for `roleuser`
-- ----------------------------
DROP TABLE IF EXISTS `roleuser`;
CREATE TABLE `roleuser` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `RoleInfoId` bigint(20) NOT NULL,
  `UserInfoId` bigint(20) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of roleuser
-- ----------------------------
INSERT INTO `roleuser` VALUES ('1', '1', '1');
INSERT INTO `roleuser` VALUES ('2', '2', '2');
INSERT INTO `roleuser` VALUES ('3', '3', '3');

-- ----------------------------
-- Table structure for `scoreinfor`
-- ----------------------------
DROP TABLE IF EXISTS `scoreinfor`;
CREATE TABLE `scoreinfor` (
  `ID` bigint(20) NOT NULL,
  `StudentID` varchar(18) COLLATE utf8_unicode_ci NOT NULL,
  `CourseID` varchar(18) COLLATE utf8_unicode_ci NOT NULL,
  `Score` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `TextTime` datetime NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of scoreinfor
-- ----------------------------

-- ----------------------------
-- Table structure for `studentinfo`
-- ----------------------------
DROP TABLE IF EXISTS `studentinfo`;
CREATE TABLE `studentinfo` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `ClassName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Age` int(4) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of studentinfo
-- ----------------------------
INSERT INTO `studentinfo` VALUES ('1', '01', '张三', '18');
INSERT INTO `studentinfo` VALUES ('2', '02', '李四', '18');

-- ----------------------------
-- Table structure for `userinfo`
-- ----------------------------
DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE `userinfo` (
  `Id` bigint(20) NOT NULL AUTO_INCREMENT,
  `Username` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Password` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of userinfo
-- ----------------------------
INSERT INTO `userinfo` VALUES ('1', 'admin', 'admin');
INSERT INTO `userinfo` VALUES ('2', 'manager', '123');
INSERT INTO `userinfo` VALUES ('3', 'teacher', 'teacher');
