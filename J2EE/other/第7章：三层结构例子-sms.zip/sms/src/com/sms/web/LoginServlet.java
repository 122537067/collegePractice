package com.sms.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sms.service.UserInfoService;

@WebServlet("/login.do")
public class LoginServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String username = req.getParameter("username");
		String pwd = req.getParameter("pwd");
		
		if(new UserInfoService().login(username, pwd))
		{
			resp.sendRedirect("/views/index.jsp");
		}
		else{
			req.setAttribute("msg", "用户名或者密码错误");
			req.getRequestDispatcher("/login.jsp").forward(req, resp);
		}
		
	}
	
	

}
