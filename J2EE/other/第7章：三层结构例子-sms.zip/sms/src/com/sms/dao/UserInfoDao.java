package com.sms.dao;

import java.sql.ResultSet;
import java.util.LinkedHashMap;
import java.util.Map;


import com.sms.model.UserInfo;

public class UserInfoDao extends BaseDao {
	
	public UserInfoDao() {
	}

	/**
	 * 根据用户名获取用户对象
	 * @param username
	 * @return
	 */
	public UserInfo getUserInfoByName(String username){
		
		String sql = "select * from UserInfo where Username=?";
		Map<String,Object> params = new LinkedHashMap<String,Object>();
		params.put("UserName", username);
		
		DbHelper db = this.createDbHelper();
		
		UserInfo user = null;
		
		try {
			db.createConnection();
			ResultSet rs = db.query(sql, params);
			
			if(rs.next()){
				user = new UserInfo();
				user.setId(rs.getLong(1));
				user.setUsername(rs.getString(2));
				user.setPassword(rs.getString(3));
			}
			
			db.closeConnection();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return user;
		
	}

}
