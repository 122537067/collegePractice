package com.sms.dao;

public class BaseDao {
	
	private DbHelper db;
	
	
	public BaseDao(){
		
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/sms";
		String user = "root";
		String pwd = "123456";
		
		this.db = new DbHelper(driver,url,user,pwd);
	}
	
	public DbHelper createDbHelper(){
		return this.db;
	}
	
	
}
