package com.sms.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sms.model.UserInfo;
import com.sms.service.UserInfoService;

public class SMSApplication {
	
	public static void main(String[] args){
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		UserInfoService userInfoService = (UserInfoService)context.getBean("service");
		
		UserInfo user = new UserInfo();
		user.setUsername("admin");
		user.setPassword("123456");
		
		userInfoService.addUser(user);
		
		System.out.println("ok");
	}

}
