package com.sms.service;

import com.sms.dao.UserInfoDao;
import com.sms.model.UserInfo;

public class UserInfoService {
	
	private UserInfoDao dao;
	
	public UserInfoDao getDao() {
		return dao;
	}

	public void setDao(UserInfoDao dao) {
		this.dao = dao;
	}

	public void addUser(UserInfo user){
		dao.add(user);
	}

}
