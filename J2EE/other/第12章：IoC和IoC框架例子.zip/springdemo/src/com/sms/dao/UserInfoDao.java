package com.sms.dao;

import com.sms.model.UserInfo;

public class UserInfoDao {
	
	public void add(UserInfo user){
		System.out.println("添加用户："+user.getUsername()+"到数据库");
	}

}
