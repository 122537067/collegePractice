package com.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sms.model.UserInfo;


public class Test3 {
	
	public static void main(String[] args){
		
		ApplicationContext context = new ClassPathXmlApplicationContext("test3.xml");
		UserInfo user = (UserInfo)context.getBean("user");
				
		System.out.println(user.toString());
	}

}
