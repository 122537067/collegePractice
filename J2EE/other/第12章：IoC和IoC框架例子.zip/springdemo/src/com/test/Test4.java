package com.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sms.model.UserInfo;
import com.sms.service.UserInfoService;


public class Test4 {
	
	public static void main(String[] args){
		
		ApplicationContext context = new ClassPathXmlApplicationContext("test4.xml");
		UserInfoService userService = (UserInfoService)context.getBean("service");
				
		userService.addUser(new UserInfo());
	}

}
