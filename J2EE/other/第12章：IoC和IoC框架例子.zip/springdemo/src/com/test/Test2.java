package com.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.test.service.UserInfoService;

public class Test2 {
	
	public static void main(String[] args){
		
		ApplicationContext context = new ClassPathXmlApplicationContext("test2.xml");
		UserInfoService userService = (UserInfoService)context.getBean("userService");
				
		userService.addUser();
	}

}
