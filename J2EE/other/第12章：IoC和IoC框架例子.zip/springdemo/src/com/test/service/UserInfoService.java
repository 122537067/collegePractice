package com.test.service;

import com.test.dao.UserInfoDao;

public class UserInfoService {
	
	private UserInfoDao dao;
	
	public UserInfoService(){
		
	}
	
	public UserInfoService(UserInfoDao dao){
		this.dao = dao;
	}
	
	public void addUser(){
		this.dao.add();
	}

}
