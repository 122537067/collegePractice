package com.test.dao;

public class UserInfoDao {
	
	public void add(){
		System.out.println("通过dao执行了一个add方法");
	}

}
