package com.test;

public class HelloSpring {
	
	private String msg;
	
	public void printMsg(){
		System.out.println("你好："+msg);
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	
	

}
