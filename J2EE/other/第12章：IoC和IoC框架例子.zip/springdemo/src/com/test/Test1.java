package com.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test1 {
	
	public static void main(String[] args){
		
		// 通过ClassPathXmlApplicationContext实例化Spring的上下文
		ApplicationContext context = new ClassPathXmlApplicationContext("test1.xml");
		
		// 通过ApplicationContext的getBean()方法，根据id来获取bean的实例
		HelloSpring helloSpring = (HelloSpring)context.getBean("hello");
				
		// 执行print()方法
		helloSpring.printMsg();
	}

}
