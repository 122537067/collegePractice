package com.test;

public class ErrorTest {
	
	public int test(int a,int b){
		return a/b;
	}
	
	public void test2() throws Exception{
		throw new Exception("测试异常");
	}

}
