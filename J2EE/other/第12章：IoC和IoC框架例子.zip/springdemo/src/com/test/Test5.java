package com.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test5 {
	
	public static void main(String[] args) throws Exception{
		
		ApplicationContext context = new ClassPathXmlApplicationContext("test5.xml");
		ErrorTest test = (ErrorTest)context.getBean("test");
				
		//test.test(2, 0);
		
		test.test2();
	}

}
