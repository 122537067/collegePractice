package com.demo;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

@WebServlet("/validusername.do")
public class ValidServlet extends HttpServlet {
	

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		valid(req,resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		valid(req,resp);
	}
	
	private void valid(HttpServletRequest req, HttpServletResponse resp) throws IOException{
		// 返回数据类型为json格式
		resp.setContentType("text/json; charset=utf-8");
		PrintWriter out = resp.getWriter();
		
		JSONObject json = new JSONObject();
		
		String username = req.getParameter("username");
		System.out.println(username);
		
		
		if(username.equals("admin")){
			json.put("success", false);
			json.put("msg", "用户名已被使用");
		}
		else{
			json.put("success", true);
			json.put("msg", "用户名可以使用");
		}
		
		System.out.println(json);
		
		out.print(json);
	}
	
	

}
