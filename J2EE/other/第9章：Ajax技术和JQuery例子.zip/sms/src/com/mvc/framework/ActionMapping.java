package com.mvc.framework;

import java.util.HashMap;
import java.util.Map;

/**
 * 配置文件中一个Action的映射信息
 * @author hp
 *
 */
public class ActionMapping {
	
	private String name;
	private String className;
	private Map<String,String> resultMap = new HashMap<String,String>();
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getResult(String name) {
		return resultMap.get(name);
	}
	public void addResultMap(String name,String result) {
		this.resultMap.put(name, result);
	}
	
	

}
