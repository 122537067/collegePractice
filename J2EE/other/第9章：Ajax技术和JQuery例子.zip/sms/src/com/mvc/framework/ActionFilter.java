package com.mvc.framework;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ActionFilter implements Filter {
	
	private ActionMappingManager mappingManager = null;

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain arg2)
			throws IOException, ServletException {
		
		HttpServletRequest request = (HttpServletRequest)arg0;
		HttpServletResponse response = (HttpServletResponse)arg1;
		
		ActionMapping am = this.getActionMapping(request);
		IAction action = ActionManager.createAction(am.getClassName());
		String resultName = action.execute(request, response);
		if(resultName==null || resultName.isEmpty()) return;

		// 页面跳转
		// 不能用 response.sendRedirect
		// 否则参数无法传递过去
		String resultView = am.getResult(resultName);
		arg0.getRequestDispatcher(resultView).forward(arg0, response);
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		String[] configFiles;
		String configStr = arg0.getInitParameter("config");
		// 加载默认配置文件
		if(configStr==null || configStr.isEmpty()){
			configFiles = new String[]{"mymvc.xml"};
		}
		else{
			configFiles = configStr.split(",");
		}
		
		this.mappingManager = new ActionMappingManager(configFiles);
	}
	
	private ActionMapping getActionMapping(HttpServletRequest request) throws ServletException{
		
		//获取请求的uri
		String uri = request.getRequestURI();
		System.out.println("uri="+uri);
	      
		//获取上下文路径
		String contextPath = request.getContextPath();
		System.out.println("contextPath="+contextPath);
	      
		//截取上下文路径以后的部分
		String actionPath = uri.substring(contextPath.length());
		System.out.println("actionPath="+actionPath);
	      
		//获取Action 名称
		String actionName =  actionPath.substring(1,actionPath.lastIndexOf('.')).trim();
		System.out.println("actionName="+actionName);
	      
		ActionMapping am = this.mappingManager.getActionMapping(actionName);
		
		return am;

	}

}
