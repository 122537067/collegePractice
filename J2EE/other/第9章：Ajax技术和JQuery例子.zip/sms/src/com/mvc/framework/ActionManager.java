package com.mvc.framework;

import javax.servlet.ServletException;

/**
 * 负责创建Action对象
 * @author hp
 *
 */
public class ActionManager {
	
	public static IAction createAction(String className) throws ServletException{
		try{
			Class<?> klass = Class.forName(className);
			IAction action = (IAction)klass.newInstance();
			return action;
		}
		catch(Exception ex){
			throw new ServletException(ex);
		}
	}

}
