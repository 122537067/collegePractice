package com.mvc.framework;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class ActionMappingManager {
	
	private static Map<String,ActionMapping> actionMappings = new HashMap<String,ActionMapping>();
	
	/**
	 * 构造时，需要将配置文件传过来。
	 * 可以有多个配置文件。
	 * @param configFiles
	 */
	public ActionMappingManager(String[] configFiles){
		for(String configFile:configFiles){
			try {
				this.init(configFile);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * 根据Action名称获取ActionMapping信息
	 * @param name
	 * @return
	 * @throws Exception 
	 */
	public ActionMapping getActionMapping(String name) throws ServletException{
		if(name==null || name.isEmpty()) return null;
		
		ActionMapping am = actionMappings.get(name);
		if(am==null) throw new ServletException(name+"Action配置信息不存在");
		
		return am;
		
	}
	
	/**
	 * 初始化方法，从配置文件加载action的映射信息
	 * @param configFileName
	 * @throws Exception 
	 */
	@SuppressWarnings("unchecked")
	public void init(String configFileName) throws Exception{
		
		if(configFileName==null || configFileName.isEmpty()) throw new Exception("configFileName为空");
		
		// 获取配置文件输入流
		InputStream is = this.getClass().getResourceAsStream("/"+configFileName);
		
		// 使用dom4j读取xml格式配置文件内容
		Document doc = new SAXReader().read(is);
		
		// 读取根元素
		Element root = doc.getRootElement();
		
		// 可能有多个的actions元素
		List<Element> actionsList = root.elements("actions");
		for(Element actions:actionsList){
			// 每个actions有很多action
			List<Element> actionList = actions.elements("action");
			for(Element action:actionList){
				// 每个action是一个ActionMapping对象
				ActionMapping mapping = new ActionMapping();
				mapping.setName(action.attributeValue("name"));
				mapping.setClassName(action.attributeValue("class"));
				
				// 有过个result
				List<Element> resultList = action.elements("result");
				for(Element result:resultList){
					String resultName = result.attributeValue("name");
					String resultUrl = result.getText();
					// success是默认名
					if(resultName==null || resultName.isEmpty()) resultName = "success";
					mapping.addResultMap(resultName, resultUrl);
				}
				
				actionMappings.put(mapping.getName(), mapping);
			}
		}
	}

}
