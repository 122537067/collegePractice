package com.sms.web;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.mvc.framework.IAction;
import com.sms.common.JsonHelper;
import com.sms.service.UserInfoService;

public class LoginAction implements IAction {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		String jsonData = JsonHelper.readJSONData(request);
		System.out.println(jsonData);
		
		JSONObject jsonRequest = new JSONObject(jsonData);
		String username = jsonRequest.getString("username");
		String pwd = jsonRequest.getString("pwd");
		
		JSONObject json = new JSONObject();
		
		if(new UserInfoService().login(username, pwd)){
			json.put("success", true);
			json.put("msg", "");
		}
		else{
			json.put("success", false);
			json.put("msg", "用户名或者密码错误");
		}
		
		PrintWriter out = response.getWriter();
		out.print(json);
		out.close();
		
		return null;
	}

}
