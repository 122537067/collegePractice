package com.sms.service;

import com.sms.dao.UserInfoDao;
import com.sms.model.UserInfo;

public class UserInfoService {
	
	public UserInfoService(){
		
	}
	
	/**
	 * 处理用户登录的逻辑，成功登录返回真，否则返回假
	 * @param username
	 * @param pwd
	 * @return
	 */
	public boolean login(String username,String pwd){
		UserInfo user = new UserInfoDao().getUserInfoByName(username);
		if(user==null) return false;
		
		if(user.getPassword().equals(pwd)) return true;
		
		return false;
		
	}

}
